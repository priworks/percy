Percy CLI Integration Guide
This guide will help you set up Percy for visual testing in your project.

Step 1: Install Percy CLI
First, you need to install the @percy/cli dependency. You can do this using npm:

$ npm install @percy/cli

Step 2: Create a Percy Project
Next, let's create a Percy project:

Visit Percy. https://percy.io/
 a) Go to the dashboard and click on Create new project.
 b) Specify the Project Name.
 c) Click Create Project.
After creating the project, Percy generates a token that identifies your project builds on their servers. Make sure to note down this token as you will need it later.

Step 3: Set Environment Variables
Export the Percy token environment variable by running the following command:

$ export PERCY_TOKEN="<your token here>"
Replace "<your token here>" with the actual token you obtained in the previous step.

Step 4: Create a snapshots.yml File
Create a snapshots.yml file in your project root. This file specifies the snapshots to be taken by Percy in the generated build. Here is a basic example:

serve: .
snapshots:
  - name: Home Page
    url: /index.html


Step 5: Run the Build
Finally, run the build with the following command:

$ npx percy snapshot snapshots.yml

This command will take snapshots as specified in your snapshots.yml file and upload them to Percy for visual comparison.