<?php 

function generate_snapshots_yml() {
	// Get all post types
	$post_types = get_post_types(array('public' => true), 'objects');
	$post_types_list = [];
	
	foreach ($post_types as $post_type) {
		if ( $post_type->name !== 'attachment' ) {
			$post_types_list[] = $post_type->name;
		}
	}

    $args = array(
        'post_type' => $post_types_list, 
        'post_status' => 'publish',
        'numberposts' => -1,
    );

    $posts = get_posts($args);
    $snapshots = [];
    foreach ($posts as $post) {
        setup_postdata($post);
        $snapshots[] = array(
            'name' => str_replace(':', '', get_the_title($post->ID)), // remove possible ":" symbol from title as it can cause issues.
            'url' => get_permalink($post->ID)
        );
    }
    wp_reset_postdata();

    $yaml = "serve: .\nsnapshots:\n";
    foreach ($snapshots as $snapshot) {
        $yaml .= "  - name: " . $snapshot['name'] . "\n";
        $yaml .= "    url: " . $snapshot['url'] . "\n";
    }
	
    $file = get_template_directory() . '/pri-assets/snapshots.yml';
    file_put_contents($file, $yaml);
}