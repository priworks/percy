1. Install Dependencies
Install the required Node.js packages:

    npm install puppeteer axe-puppeteer browserstack-local

========================================================================

2. Running the Test
Set Up BrowserStack Credentials
Make sure you have a BrowserStack account. Obtain your BrowserStack username and access key.

Set the environment variables for your BrowserStack credentials:

    export BROWSERSTACK_USERNAME=hrachbabayan_wHvZUq
    export BROWSERSTACK_ACCESS_KEY=QywTFxpJd5o3989TsjcC

========================================================================

3. Update the Test Script
Replace the placeholder URL (http://your-wordpress-site.com) in the test.js script with the URL of your WordPress website.

========================================================================

4. Run the Test Script
Run the test.js script to perform accessibility testing:

    node test.js

========================================================================

5. Generating the HTML Report
After running the test, an HTML report will be generated automatically. This report includes detailed information about accessibility violations found during the test.

Viewing the HTML Report
Open the accessibility-report.html file in a web browser to view the HTML report.

Customizing the HTML Report
You can customize the design and layout of the HTML report by modifying the generateHtmlReport function in the test.js script. Adjust the CSS styles and HTML structure according to your preferences.