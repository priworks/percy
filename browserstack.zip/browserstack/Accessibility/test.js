const fs = require('fs');
const puppeteer = require('puppeteer');
const { AxePuppeteer } = require('axe-puppeteer');
const browserstack = require('browserstack-local');

const bsLocal = new browserstack.Local();

const bsLocalArgs = {
  key: process.env.BROWSERSTACK_ACCESS_KEY,
  forcelocal: true,
};

bsLocal.start(bsLocalArgs, async function(error) {
  if (error) return console.error('Error starting BrowserStack Local:', error);

  console.log('BrowserStack Local started');

  const browser = await puppeteer.launch({
    args: ['--no-sandbox', '--disable-setuid-sandbox']
  });

  const page = await browser.newPage();
  const urls = await getAllInternalLinks(page, 'https://eisholdings.com/');

  const allResults = [];

  for (const url of urls) {
    console.log(`Testing ${url}`);
    await page.goto(url);
    const results = await new AxePuppeteer(page).analyze();
    allResults.push({ url, violations: results.violations });
    console.log(`Accessibility Violations for ${url}:`, results.violations);
  }

  // Save JSON results to a file
  fs.writeFileSync('accessibility-results.json', JSON.stringify(allResults, null, 2));

  // Generate HTML report
  const htmlReport = generateHtmlReport(allResults);
  fs.writeFileSync('accessibility-report.html', htmlReport);

  await browser.close();
  bsLocal.stop(function() {
    console.log('BrowserStack Local stopped');
  });
});

async function getAllInternalLinks(page, rootUrl) {
  await page.goto(rootUrl);
  const links = await page.$$eval('a', anchors => anchors.map(a => a.href));
  const internalLinks = links.filter(link => link.startsWith(rootUrl));
  return Array.from(new Set(internalLinks)); // Remove duplicates
}


function generateHtmlReport(results) {
  let html = `
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Accessibility Report</title>
  <style>
    body { font-family: Arial, sans-serif; background-color: white; }  /* Set body background to white */
    .violation { 
      border: 1px solid #ccc; 
      border-radius: 5px; 
      margin-bottom: 20px; 
      background-color: white; 
    }
    .violation h3 { 
      background-color: #f2f2f2; 
      padding: 10px; 
      margin: 0; 
      cursor: pointer;  /* Add cursor pointer for clickable h3 */
    }
    .violation .details { 
      padding: 10px; 
      background: #fff; 
      display: none;  /* Initially hide violation details */
    }
    .violation .details p { margin: 5px 0; }
    .violation.active .details { display: block; } /* Show details for active violation */
    .nav { margin-bottom: 30px; display: flex; }  /* Flexbox for two columns */
    .nav a { display: block; color: #112839; text-decoration: none; margin: 5px 0; }
    .nav a:hover { text-decoration: underline; }
    .nav ul { flex: 1;  /* Make lists occupy full width of their column */ }
    .page-list { columns: 3; }
    #jump-to-top {
      position: fixed;  /* Fix button to bottom right corner */
      bottom: 10px;
      right: 10px;
      padding: 10px 20px;
      background-color: #4CAF50;
      color: white;
      border: none;
      border-radius: 5px;
      cursor: pointer;
    }
  </style>
</head>
<body>
  <h1>Tested Pages List</h1>
  <nav class="nav">
    <ul class="page-list">
  `;

  results.forEach((result, index) => {
    // Extract the base URL without the hash fragment (handle missing URLs)
    const baseUrl = result?.url?.split('#')[0] || "No URL available";
    html += `<li><a href="#page-${index}">${baseUrl}</a></li>`;
  });

  html += `
    </ul>
  </nav>
  `;

  results.forEach((result, index) => {
    html += `<h2><a id="page-${index}" href="${result.url}" target="_blank">Accessibility Violations for ${result.url}</a></h2>`;
    result.violations.forEach((violation) => {
      let violationHTML = '';
      violationHTML += `<div class="violation">`;
      violationHTML += `<h3 class="violation-title">${violation.id}</h3>`; // Add class for styling
      violationHTML += `<div class="details">`;
      violationHTML += `<p><strong>Description:</strong> ${violation.description}</p>`;
      violationHTML += `<p><strong>Help:</strong> ${violation.help}</p>`;
      violationHTML += `<p><strong>Impact:</strong> ${violation.impact}</p>`;
      violationHTML += `<h3>Elements:</h3>`;
      violation.nodes.forEach(node => {
        violationHTML += `<p><strong>Target:</strong> ${node.target.join(', ')}</p>`;
        violationHTML += `<p><strong>Failure Summary:</strong> ${node.failureSummary}</p>`;
        violationHTML += `<hr>`;
      });
      violationHTML += `</div>`;
      violationHTML += `</div>`;
      html += violationHTML
    });
    if (index < results.length - 1) {
      html += `<hr>`;
    }
  });

  html += `
  <a href="#" id="jump-to-top">Jump to Top</a>
    <script>
      const violationTitles = document.querySelectorAll('.violation-title'); // Select all violation titles (h3)
      violationTitles.forEach(title => {
        title.addEventListener('click', function() {
          const violationDetails = this.nextElementSibling; // Get the details element next to the clicked title
          const currentActive = document.querySelector('.violation.active'); // Get the currently active violation
  
          // Toggle active class and visibility of details
          if (currentActive) {
            currentActive.classList.remove('active');
            currentActive.querySelector('.details').style.display = 'none';
          }
  
          violationDetails.classList.toggle('active'); // Toggle active class for the clicked violation details
          violationDetails.style.display = violationDetails.classList.contains('active') ? 'block' : 'none';
        });
      });
    </script>
  </body>
  </html>`;

  return html; // Add return statement to return the generated HTML
}
  

